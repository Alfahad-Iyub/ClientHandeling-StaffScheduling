package com.example.chatter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
